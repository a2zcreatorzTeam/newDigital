<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Digital Insurance - State Life</title>
    <meta name="description" content="Digital Insurance - State Life">
    <meta name="viewport" content="width=device-width, initial-scale=1">
   <meta name="csrf-token" content="{{ csrf_token() }}">

    <link rel="shortcut icon" type="image/x-icon" href="{{ asset('frontend\images\favicon.jpg') }}">

    <!-- Place favicon.ico in the root directory -->


    <!-- CSS here -->

    <link rel="stylesheet" href="{{asset('frontend/css/bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{asset('frontend/css/animate.min.css')}}">
    <link rel="stylesheet" href="{{asset('frontend/css/magnific-popup.css')}}">
    <link rel="stylesheet" href="{{asset('frontend/css/fontawesome-all.min.css')}}">
    <link rel="stylesheet" href="{{asset('frontend/css/flaticon.css')}}">
    <link rel="stylesheet" href="{{asset('frontend/css/odometer.css')}}">
    <link rel="stylesheet" href="{{asset('frontend/css/swiper-bundle.css')}}">
    <link rel="stylesheet" href="{{asset('frontend/css/aos.css')}}">
    <link rel="stylesheet" href="{{asset('frontend/css/default.css')}}">
    <link rel="stylesheet" href="{{asset('frontend/css/main.css')}}">
    <link rel="stylesheet" href="{{asset('frontend/css/login.css')}}">


</head>
<style>
    /* Target Chrome, Safari, Edge, and Opera */
    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
    }

    /* Target Firefox */
    input[type=number] {
        -moz-appearance: textfield;
    }
</style>

<body>

    <div id="loader_data" style="
    display:none;
    position:fixed;
    top:0;
    left:0;
    width:100%;
    height:100%;
    background:rgba(0,0,0,0.5);
    z-index:9999;
    text-align:center;
">
        <div style="position:absolute; top:50%; left:50%; transform:translate(-50%, -50%);">

            <!-- ✅ Your GIF Loader -->
             
            <img src="{{asset('frontend/images/loading-slic.gif')}}"
                alt="Loading..."
                style="width:100px;">

        </div>
    </div>

    <!--Preloader-->
    <div id="preloader">
        <div id="loader" class="loader">
            <div class="loader-container">
                <div class="loader-icon"><img src="{{ asset('frontend/images/preloader-state.png') }}" alt="Preloader"></div>
            </div>
        </div>
    </div>
    <!--Preloader-end -->



    <!-- Scroll-top -->
    <button class="scroll__top scroll-to-target" data-target="html">
        <i class="fas fa-angle-up"></i>
    </button>
    <!-- Scroll-top-end-->

    <!-- header-area -->
    <header class="transparent-header">
        {{-- here when user login then auth navbar should be login else without-auth navbar--}}
        <div id="authNavbar">
            @include('frontend.layout.navbars.auth-navbar')
        </div>
        <div id="guestNavbar">
            @include('frontend.layout.navbars.without-auth-navbar')
        </div>

        <!-- offCanvas-menu -->
        <div class="offCanvas__info">
            <div class="offCanvas__close-icon menu-close">
                <button class="offcanvas-close"><i class="far fa-window-close"></i></button>
            </div>
            <div class="offCanvas__logo mb-30">
                <a href="index.html"><img src="{{ asset('frontend/images/logo.png')}}" alt="Logo"></a>
            </div>
            <div class="offCanvas__side-info mb-30">
                <div class="contact-list mb-30">
                    <!-- Sign In Form -->
                    @include('frontend.layout.authentication.signin')
                    <!-- forget password-->
                    @include('frontend.layout.authentication.forget')
                    <!-- Sign Up Form -->
                    @include('frontend.layout.authentication.signup')
                     <!-- OTP Form -->
                    @include('frontend.layout.authentication.otp')

                </div>

            </div>
        </div>
        <div class="offCanvas__overly"></div>
        <!-- offCanvas-menu-end -->

    </header>
    <!-- header-area-end -->
<div id="nominee" role="tabpanel" aria-labelledby="basic_Details-tab" class="tab-pane fade">
    <div class="container">
        <div class="row">
            <h3 class="col-12 ib-form-subheading">Nominee</h3>
            <!-- 37. Nominee & Appointee Details -->
            <div class="row">
                <!-- (A) Name of Nominee -->
                <div class="col-md-6 px-0 px-sm-3 mb-3">
                    <div>
                        <div>
                            <div>
                                <label>37. Name of nominee (s) (نام نامزدگی)</label>
                                <div class="jbl-field">
                                    <input type="text" name="nominee_name" class="form-control jbl-dynamic-input" id="nominee_name" placeholder="Enter nominee name / نامزد فرد کا نام">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- (B) C.N.I.C. / B-Form No -->
                <div class="col-md-6 px-0 px-sm-3 mb-3">
                    <div>
                        <div>
                            <div>
                                <label>C.N.I.C. No (Adult) or B-Form No (Minor) (شناختی کارڈ / بی فارم نمبر)</label>
                                <div class="jbl-field">
                                    <input type="text" name="nominee_cnic" class="form-control jbl-dynamic-input" id="nominee_cnic" placeholder="Enter CNIC or B-Form / شناختی کارڈ نمبر">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- (C) Age -->
                <div class="col-md-6 px-0 px-sm-3 mb-3">
                    <div>
                        <div>
                            <div>
                                <label>Age (عمر)</label>
                                <div class="jbl-field">
                                    <input type="number" name="nominee_age" class="form-control jbl-dynamic-input" id="nominee_age" placeholder="Enter age / عمر درج کریں">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- (D) Relationship with you -->
                <div class="col-md-6 px-0 px-sm-3 mb-3">
                    <div>
                        <div>
                            <div>
                                <label>Relationship with you (آپ کے ساتھ رشتہ)</label>
                                <div class="jbl-field">
                                    <input type="text" name="nominee_relationship" class="form-control jbl-dynamic-input" id="nominee_relationship" placeholder="Enter relationship / رشتہ درج کریں">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- If Nominee is Minor (Appointee Section) -->
            <div class="row">
                <div class="col-12 px-0 px-sm-3 mb-2">
                    <small class="text-muted fw-bold">If nominee is minor an Appointee under Section 72 must be Designated (اگر نامزد وارث نابالغ ہے تو سرپرست کی ماموری لازمی ہے)</small>
                </div>

                <!-- (E) Appointee's Name -->
                <div class="col-md-6 px-0 px-sm-3 mb-3">
                    <div>
                        <div>
                            <div>
                                <label>Appointee's Name (نام سرپرست)</label>
                                <div class="jbl-field">
                                    <input type="text" name="appointee_name" class="form-control jbl-dynamic-input" id="appointee_name" placeholder="Enter appointee name / سرپرست کا نام">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- (F) Appointee's Relationship with nominee -->
                <div class="col-md-6 px-0 px-sm-3 mb-3">
                    <div>
                        <div>
                            <div>
                                <label>Appointee's Relationship with nominee (نامزد وارث سے سرپرست کا رشتہ)</label>
                                <div class="jbl-field">
                                    <input type="text" name="appointee_relationship" class="form-control jbl-dynamic-input" id="appointee_relationship" placeholder="Enter relationship / سرپرست سے رشتہ">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- (H) Appointee's C.N.I.C. No -->
                <div class="col-md-6 px-0 px-sm-3 mb-3">
                    <div>
                        <div>
                            <div>
                                <label>Appointee's C.N.I.C. No (سرپرست کا شناختی کارڈ نمبر)</label>
                                <div class="jbl-field">
                                    <input type="text" name="appointee_cnic" class="form-control jbl-dynamic-input" id="appointee_cnic" placeholder="Enter appointee CNIC / سرپرست کا شناختی کارڈ">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 d-flex justify-content-between mt-4">
                <button type="button" class="btn btn-secondary ib-prev-btn">Previous</button>
                <button type="button" class="btn btn-primary ib-next-btn">Next</button>
            </div>
        </div>
    </div>
</div>
@push('js')

@endpush